﻿
namespace WinFormsApp1
{
    partial class foorm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(foorm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.شهرهایپرطرفداراستانفارسToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.شیرازToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مرودشتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جهرمToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.آبادهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لارToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جاهایدیدنیفارسToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تختجمشیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.باغارمToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بازاروکیلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.هنرمندانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.آتوساToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.شاپورساسانیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.شیخروزبهانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.غذاهایمحلیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.کلمپلوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.شکرپلوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قنبرپلوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لوبیاپلوشیرازیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تنظیماتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.رنگمتنToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aa = new System.Windows.Forms.ToolStripMenuItem();
            this.bb = new System.Windows.Forms.ToolStripMenuItem();
            this.cc = new System.Windows.Forms.ToolStripMenuItem();
            this.رنگزمینهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پخشموزیکToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.w = new System.Windows.Forms.ToolStripMenuItem();
            this.v = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.شهرهایپرطرفداراستانفارسToolStripMenuItem,
            this.جاهایدیدنیفارسToolStripMenuItem,
            this.هنرمندانToolStripMenuItem,
            this.غذاهایمحلیToolStripMenuItem,
            this.تنظیماتToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(885, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // شهرهایپرطرفداراستانفارسToolStripMenuItem
            // 
            this.شهرهایپرطرفداراستانفارسToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.شیرازToolStripMenuItem,
            this.مرودشتToolStripMenuItem,
            this.جهرمToolStripMenuItem,
            this.آبادهToolStripMenuItem,
            this.لارToolStripMenuItem});
            this.شهرهایپرطرفداراستانفارسToolStripMenuItem.Name = "شهرهایپرطرفداراستانفارسToolStripMenuItem";
            this.شهرهایپرطرفداراستانفارسToolStripMenuItem.Size = new System.Drawing.Size(134, 20);
            this.شهرهایپرطرفداراستانفارسToolStripMenuItem.Text = "شهرهای پرطرفدار فارس";
            this.شهرهایپرطرفداراستانفارسToolStripMenuItem.Click += new System.EventHandler(this.شهرهایپرطرفداراستانفارسToolStripMenuItem_Click);
            // 
            // شیرازToolStripMenuItem
            // 
            this.شیرازToolStripMenuItem.Image = global::WinFormsApp1.Properties.Resources._17038267926184663436187473249170;
            this.شیرازToolStripMenuItem.Name = "شیرازToolStripMenuItem";
            this.شیرازToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.شیرازToolStripMenuItem.Text = "شیراز";
            this.شیرازToolStripMenuItem.Click += new System.EventHandler(this.شیرازToolStripMenuItem_Click);
            // 
            // مرودشتToolStripMenuItem
            // 
            this.مرودشتToolStripMenuItem.Image = global::WinFormsApp1.Properties.Resources._17038268461568404985099539119944;
            this.مرودشتToolStripMenuItem.Name = "مرودشتToolStripMenuItem";
            this.مرودشتToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.مرودشتToolStripMenuItem.Text = "مرودشت";
            this.مرودشتToolStripMenuItem.Click += new System.EventHandler(this.مرودشتToolStripMenuItem_Click);
            // 
            // جهرمToolStripMenuItem
            // 
            this.جهرمToolStripMenuItem.Image = global::WinFormsApp1.Properties.Resources._17038268873591743370754314421411;
            this.جهرمToolStripMenuItem.Name = "جهرمToolStripMenuItem";
            this.جهرمToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.جهرمToolStripMenuItem.Text = "جهرم";
            this.جهرمToolStripMenuItem.Click += new System.EventHandler(this.جهرمToolStripMenuItem_Click);
            // 
            // آبادهToolStripMenuItem
            // 
            this.آبادهToolStripMenuItem.Image = global::WinFormsApp1.Properties.Resources._17038269296453698781203008831447;
            this.آبادهToolStripMenuItem.Name = "آبادهToolStripMenuItem";
            this.آبادهToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.آبادهToolStripMenuItem.Text = "آباده";
            this.آبادهToolStripMenuItem.Click += new System.EventHandler(this.آبادهToolStripMenuItem_Click);
            // 
            // لارToolStripMenuItem
            // 
            this.لارToolStripMenuItem.Image = global::WinFormsApp1.Properties.Resources._17038269760632353564968292296582;
            this.لارToolStripMenuItem.Name = "لارToolStripMenuItem";
            this.لارToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.لارToolStripMenuItem.Text = "لار";
            this.لارToolStripMenuItem.Click += new System.EventHandler(this.لارToolStripMenuItem_Click);
            // 
            // جاهایدیدنیفارسToolStripMenuItem
            // 
            this.جاهایدیدنیفارسToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تختجمشیدToolStripMenuItem,
            this.باغارمToolStripMenuItem,
            this.بازاروکیلToolStripMenuItem});
            this.جاهایدیدنیفارسToolStripMenuItem.Name = "جاهایدیدنیفارسToolStripMenuItem";
            this.جاهایدیدنیفارسToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.جاهایدیدنیفارسToolStripMenuItem.Text = "جاهای دیدنی شیراز";
            // 
            // تختجمشیدToolStripMenuItem
            // 
            this.تختجمشیدToolStripMenuItem.Name = "تختجمشیدToolStripMenuItem";
            this.تختجمشیدToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.تختجمشیدToolStripMenuItem.Text = "تخت جمشید";
            this.تختجمشیدToolStripMenuItem.Click += new System.EventHandler(this.تختجمشیدToolStripMenuItem_Click);
            // 
            // باغارمToolStripMenuItem
            // 
            this.باغارمToolStripMenuItem.Name = "باغارمToolStripMenuItem";
            this.باغارمToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.باغارمToolStripMenuItem.Text = "باغ ارم";
            this.باغارمToolStripMenuItem.Click += new System.EventHandler(this.باغارمToolStripMenuItem_Click);
            // 
            // بازاروکیلToolStripMenuItem
            // 
            this.بازاروکیلToolStripMenuItem.Name = "بازاروکیلToolStripMenuItem";
            this.بازاروکیلToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.بازاروکیلToolStripMenuItem.Text = "حافظیه";
            this.بازاروکیلToolStripMenuItem.Click += new System.EventHandler(this.بازاروکیلToolStripMenuItem_Click);
            // 
            // هنرمندانToolStripMenuItem
            // 
            this.هنرمندانToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.آتوساToolStripMenuItem,
            this.شاپورساسانیToolStripMenuItem,
            this.شیخروزبهانToolStripMenuItem});
            this.هنرمندانToolStripMenuItem.Name = "هنرمندانToolStripMenuItem";
            this.هنرمندانToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.هنرمندانToolStripMenuItem.Text = "نامداران";
            // 
            // آتوساToolStripMenuItem
            // 
            this.آتوساToolStripMenuItem.Name = "آتوساToolStripMenuItem";
            this.آتوساToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.آتوساToolStripMenuItem.Text = "آتوسا";
            this.آتوساToolStripMenuItem.Click += new System.EventHandler(this.آتوساToolStripMenuItem_Click);
            // 
            // شاپورساسانیToolStripMenuItem
            // 
            this.شاپورساسانیToolStripMenuItem.Name = "شاپورساسانیToolStripMenuItem";
            this.شاپورساسانیToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.شاپورساسانیToolStripMenuItem.Text = "شاپور ساسانی";
            this.شاپورساسانیToolStripMenuItem.Click += new System.EventHandler(this.شاپورساسانیToolStripMenuItem_Click);
            // 
            // شیخروزبهانToolStripMenuItem
            // 
            this.شیخروزبهانToolStripMenuItem.Name = "شیخروزبهانToolStripMenuItem";
            this.شیخروزبهانToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.شیخروزبهانToolStripMenuItem.Text = "شیخ روزبهان";
            this.شیخروزبهانToolStripMenuItem.Click += new System.EventHandler(this.شیخروزبهانToolStripMenuItem_Click);
            // 
            // غذاهایمحلیToolStripMenuItem
            // 
            this.غذاهایمحلیToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.کلمپلوToolStripMenuItem,
            this.شکرپلوToolStripMenuItem,
            this.قنبرپلوToolStripMenuItem,
            this.لوبیاپلوشیرازیToolStripMenuItem});
            this.غذاهایمحلیToolStripMenuItem.Name = "غذاهایمحلیToolStripMenuItem";
            this.غذاهایمحلیToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.غذاهایمحلیToolStripMenuItem.Text = "غذاهای محلی";
            // 
            // کلمپلوToolStripMenuItem
            // 
            this.کلمپلوToolStripMenuItem.Name = "کلمپلوToolStripMenuItem";
            this.کلمپلوToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.کلمپلوToolStripMenuItem.Text = "کلم پلو";
            this.کلمپلوToolStripMenuItem.Click += new System.EventHandler(this.کلمپلوToolStripMenuItem_Click);
            // 
            // شکرپلوToolStripMenuItem
            // 
            this.شکرپلوToolStripMenuItem.Name = "شکرپلوToolStripMenuItem";
            this.شکرپلوToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.شکرپلوToolStripMenuItem.Text = "شکر پلو";
            this.شکرپلوToolStripMenuItem.Click += new System.EventHandler(this.شکرپلوToolStripMenuItem_Click);
            // 
            // قنبرپلوToolStripMenuItem
            // 
            this.قنبرپلوToolStripMenuItem.Name = "قنبرپلوToolStripMenuItem";
            this.قنبرپلوToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.قنبرپلوToolStripMenuItem.Text = "قنبر پلو";
            this.قنبرپلوToolStripMenuItem.Click += new System.EventHandler(this.قنبرپلوToolStripMenuItem_Click);
            // 
            // لوبیاپلوشیرازیToolStripMenuItem
            // 
            this.لوبیاپلوشیرازیToolStripMenuItem.Name = "لوبیاپلوشیرازیToolStripMenuItem";
            this.لوبیاپلوشیرازیToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.لوبیاپلوشیرازیToolStripMenuItem.Text = "لوبیا پلو شیرازی";
            this.لوبیاپلوشیرازیToolStripMenuItem.Click += new System.EventHandler(this.لوبیاپلوشیرازیToolStripMenuItem_Click);
            // 
            // تنظیماتToolStripMenuItem
            // 
            this.تنظیماتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.رنگمتنToolStripMenuItem,
            this.رنگزمینهToolStripMenuItem,
            this.پخشموزیکToolStripMenuItem,
            this.toolStripSeparator1,
            this.w,
            this.v,
            this.خروجToolStripMenuItem1});
            this.تنظیماتToolStripMenuItem.Name = "تنظیماتToolStripMenuItem";
            this.تنظیماتToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.تنظیماتToolStripMenuItem.Text = "تنظیمات";
            this.تنظیماتToolStripMenuItem.Click += new System.EventHandler(this.تنظیماتToolStripMenuItem_Click);
            // 
            // رنگمتنToolStripMenuItem
            // 
            this.رنگمتنToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aa,
            this.bb,
            this.cc});
            this.رنگمتنToolStripMenuItem.Name = "رنگمتنToolStripMenuItem";
            this.رنگمتنToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.رنگمتنToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.رنگمتنToolStripMenuItem.Text = "رنگ متن";
            this.رنگمتنToolStripMenuItem.Click += new System.EventHandler(this.رنگمتنToolStripMenuItem_Click);
            // 
            // aa
            // 
            this.aa.Name = "aa";
            this.aa.Size = new System.Drawing.Size(180, 22);
            this.aa.Text = "سفید";
            this.aa.Click += new System.EventHandler(this.سفیدToolStripMenuItem_Click);
            // 
            // bb
            // 
            this.bb.Name = "bb";
            this.bb.Size = new System.Drawing.Size(180, 22);
            this.bb.Text = "سیاه";
            this.bb.Click += new System.EventHandler(this.bb_Click);
            // 
            // cc
            // 
            this.cc.Name = "cc";
            this.cc.Size = new System.Drawing.Size(180, 22);
            this.cc.Text = "ابی";
            this.cc.Click += new System.EventHandler(this.cc_Click);
            // 
            // رنگزمینهToolStripMenuItem
            // 
            this.رنگزمینهToolStripMenuItem.Name = "رنگزمینهToolStripMenuItem";
            this.رنگزمینهToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.رنگزمینهToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.رنگزمینهToolStripMenuItem.Text = "رنگ زمینه";
            this.رنگزمینهToolStripMenuItem.Click += new System.EventHandler(this.رنگزمینهToolStripMenuItem_Click);
            // 
            // پخشموزیکToolStripMenuItem
            // 
            this.پخشموزیکToolStripMenuItem.Name = "پخشموزیکToolStripMenuItem";
            this.پخشموزیکToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.پخشموزیکToolStripMenuItem.Text = "انتخاب فونت ";
            this.پخشموزیکToolStripMenuItem.Click += new System.EventHandler(this.پخشموزیکToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // w
            // 
            this.w.Name = "w";
            this.w.Size = new System.Drawing.Size(180, 22);
            this.w.Text = "پخش موزیک";
            this.w.Click += new System.EventHandler(this.توقفموزیکToolStripMenuItem_Click);
            // 
            // v
            // 
            this.v.Name = "v";
            this.v.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.v.Size = new System.Drawing.Size(180, 22);
            this.v.Text = "توقف موزیک";
            this.v.Click += new System.EventHandler(this.خروجToolStripMenuItem_Click);
            // 
            // خروجToolStripMenuItem1
            // 
            this.خروجToolStripMenuItem1.Name = "خروجToolStripMenuItem1";
            this.خروجToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.خروجToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.خروجToolStripMenuItem1.Text = "خروج";
            this.خروجToolStripMenuItem1.Click += new System.EventHandler(this.خروجToolStripMenuItem1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(450, 42);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox1.Size = new System.Drawing.Size(414, 398);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            this.textBox1.Visible = false;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox2.Location = new System.Drawing.Point(450, 101);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox2.Size = new System.Drawing.Size(414, 297);
            this.textBox2.TabIndex = 2;
            this.textBox2.Text = resources.GetString("textBox2.Text");
            this.textBox2.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox3.Location = new System.Drawing.Point(450, 78);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox3.Size = new System.Drawing.Size(414, 320);
            this.textBox3.TabIndex = 2;
            this.textBox3.Text = resources.GetString("textBox3.Text");
            this.textBox3.Visible = false;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox4.Location = new System.Drawing.Point(450, 101);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox4.Size = new System.Drawing.Size(414, 265);
            this.textBox4.TabIndex = 2;
            this.textBox4.Text = resources.GetString("textBox4.Text");
            this.textBox4.Visible = false;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox5.Location = new System.Drawing.Point(450, 98);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox5.Size = new System.Drawing.Size(414, 268);
            this.textBox5.TabIndex = 2;
            this.textBox5.Text = resources.GetString("textBox5.Text");
            this.textBox5.Visible = false;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WinFormsApp1.Properties.Resources._17038267926184663436187473249170;
            this.pictureBox1.Location = new System.Drawing.Point(40, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(366, 347);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(40, 42);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(366, 347);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(40, 42);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(366, 356);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(40, 42);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(366, 356);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(40, 42);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(366, 356);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox6.Location = new System.Drawing.Point(289, 166);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox6.Size = new System.Drawing.Size(315, 163);
            this.textBox6.TabIndex = 8;
            this.textBox6.Text = resources.GetString("textBox6.Text");
            this.textBox6.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::WinFormsApp1.Properties.Resources._3bd37486_cd37_4097_88ac_19bbf25c9e6f_840x560;
            this.pictureBox6.Location = new System.Drawing.Point(29, 42);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(227, 169);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 9;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::WinFormsApp1.Properties.Resources._8f41999b_c320_4024_8b54_c88b694480c0_350x0;
            this.pictureBox7.Location = new System.Drawing.Point(637, 42);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(227, 169);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::WinFormsApp1.Properties.Resources._1683356922_960_شهرهای_دیدنی_استان_فارس;
            this.pictureBox8.Location = new System.Drawing.Point(637, 293);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(227, 169);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 11;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::WinFormsApp1.Properties.Resources._61cdc8ad_6c41_44a6_9e91_3375c5d27f36_840x560;
            this.pictureBox9.Location = new System.Drawing.Point(29, 293);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(227, 169);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 12;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Visible = false;
            // 
            // textBox7
            // 
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox7.Location = new System.Drawing.Point(279, 166);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox7.Size = new System.Drawing.Size(342, 189);
            this.textBox7.TabIndex = 13;
            this.textBox7.Text = resources.GetString("textBox7.Text");
            this.textBox7.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::WinFormsApp1.Properties.Resources._780a7669_c659_4f4a_a855_ad265ec705ed_840x560___Copy;
            this.pictureBox10.Location = new System.Drawing.Point(29, 42);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(227, 169);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 14;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Visible = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::WinFormsApp1.Properties.Resources._6b318620_928d_4d44_ac89_0e03f9ff5e48_840x560;
            this.pictureBox11.Location = new System.Drawing.Point(637, 42);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(227, 169);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 14;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Visible = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::WinFormsApp1.Properties.Resources.e1538593_f5a7_4aa9_a435_9acbd9a49deb_350x0;
            this.pictureBox12.Location = new System.Drawing.Point(637, 293);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(227, 169);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 15;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Visible = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::WinFormsApp1.Properties.Resources.ce1502b8_3c50_4b45_9752_5811c5bc15df_840x560;
            this.pictureBox13.Location = new System.Drawing.Point(29, 293);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(227, 169);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 16;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Visible = false;
            // 
            // textBox8
            // 
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox8.Location = new System.Drawing.Point(289, 175);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox8.Size = new System.Drawing.Size(322, 172);
            this.textBox8.TabIndex = 17;
            this.textBox8.Text = resources.GetString("textBox8.Text");
            this.textBox8.Visible = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::WinFormsApp1.Properties.Resources._2cc90b71_5096_42fd_a0c9_efa156d5c5a8_350x0;
            this.pictureBox14.Location = new System.Drawing.Point(29, 42);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(227, 169);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 18;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Visible = false;
            this.pictureBox14.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::WinFormsApp1.Properties.Resources._1683356922_545_شهرهای_دیدنی_استان_فارس___Copy;
            this.pictureBox15.Location = new System.Drawing.Point(29, 293);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(227, 169);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 19;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Visible = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::WinFormsApp1.Properties.Resources._51cb41c8_1250_41bd_849c_9010eddddcde_840x560;
            this.pictureBox16.Location = new System.Drawing.Point(637, 42);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(227, 169);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 19;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Visible = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::WinFormsApp1.Properties.Resources.cd79695e_e251_41e3_b01e_f8eb242b9ca9_350x0;
            this.pictureBox17.Location = new System.Drawing.Point(637, 293);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(227, 169);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 20;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Visible = false;
            this.pictureBox17.Click += new System.EventHandler(this.pictureBox17_Click);
            // 
            // textBox9
            // 
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox9.Location = new System.Drawing.Point(482, 162);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox9.Size = new System.Drawing.Size(290, 193);
            this.textBox9.TabIndex = 21;
            this.textBox9.Text = "آتوسا دختر کوروش بزرگ مؤسس سلسله هخامنشیان و مادرش ماندانا بود. چون در دوره هخامن" +
    "شیان، ازدواج‌ها مصلحتی و سیاسی بود وی ابتدا همسر کمبوجیه و بعد بردیا و سپس زن دا" +
    "ریوش اول دومین پادشاه هخامنشیان شد";
            this.textBox9.Visible = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::WinFormsApp1.Properties.Resources._3080794___Copy;
            this.pictureBox18.Location = new System.Drawing.Point(71, 69);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(283, 342);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 22;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Visible = false;
            // 
            // textBox10
            // 
            this.textBox10.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox10.Location = new System.Drawing.Point(471, 131);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox10.Size = new System.Drawing.Size(322, 249);
            this.textBox10.TabIndex = 23;
            this.textBox10.Text = resources.GetString("textBox10.Text");
            this.textBox10.Visible = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::WinFormsApp1.Properties.Resources._3080795;
            this.pictureBox19.Location = new System.Drawing.Point(59, 78);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(373, 342);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 24;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Visible = false;
            // 
            // textBox11
            // 
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox11.Location = new System.Drawing.Point(505, 145);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox11.Size = new System.Drawing.Size(267, 210);
            this.textBox11.TabIndex = 25;
            this.textBox11.Text = resources.GetString("textBox11.Text");
            this.textBox11.Visible = false;
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::WinFormsApp1.Properties.Resources._3080798;
            this.pictureBox20.Location = new System.Drawing.Point(71, 78);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(344, 342);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 26;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Visible = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::WinFormsApp1.Properties.Resources._17038339460708909941353556503231;
            this.pictureBox21.Location = new System.Drawing.Point(40, 69);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(421, 355);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 27;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Visible = false;
            // 
            // textBox12
            // 
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox12.Location = new System.Drawing.Point(482, 140);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox12.Size = new System.Drawing.Size(304, 258);
            this.textBox12.TabIndex = 28;
            this.textBox12.Text = resources.GetString("textBox12.Text");
            this.textBox12.Visible = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = global::WinFormsApp1.Properties.Resources._170383401188651712554918062969241;
            this.pictureBox22.Location = new System.Drawing.Point(86, 86);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(358, 347);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 29;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Visible = false;
            // 
            // textBox13
            // 
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox13.Location = new System.Drawing.Point(488, 159);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox13.Size = new System.Drawing.Size(305, 207);
            this.textBox13.TabIndex = 30;
            this.textBox13.Text = resources.GetString("textBox13.Text");
            this.textBox13.Visible = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::WinFormsApp1.Properties.Resources._17038340326063502452057143949499;
            this.pictureBox23.Location = new System.Drawing.Point(71, 98);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(382, 326);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 31;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Visible = false;
            // 
            // textBox14
            // 
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox14.Location = new System.Drawing.Point(518, 175);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox14.Size = new System.Drawing.Size(275, 166);
            this.textBox14.TabIndex = 32;
            this.textBox14.Text = resources.GetString("textBox14.Text");
            this.textBox14.Visible = false;
            this.textBox14.TextChanged += new System.EventHandler(this.textBox14_TextChanged);
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::WinFormsApp1.Properties.Resources._17038340503593305857592850596479;
            this.pictureBox24.Location = new System.Drawing.Point(86, 98);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(375, 322);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox24.TabIndex = 33;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Visible = false;
            this.pictureBox24.Click += new System.EventHandler(this.pictureBox24_Click);
            // 
            // textBox15
            // 
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox15.Location = new System.Drawing.Point(505, 166);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox15.Size = new System.Drawing.Size(267, 200);
            this.textBox15.TabIndex = 34;
            this.textBox15.Text = resources.GetString("textBox15.Text");
            this.textBox15.Visible = false;
            // 
            // foorm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(885, 497);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "foorm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem شهرهایپرطرفداراستانفارسToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جاهایدیدنیفارسToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem شیرازToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مرودشتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جهرمToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem آبادهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لارToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem هنرمندانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem غذاهایمحلیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تنظیماتToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.ToolStripMenuItem تختجمشیدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem باغارمToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بازاروکیلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem آتوساToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem شاپورساسانیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem شیخروزبهانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کلمپلوToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem شکرپلوToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قنبرپلوToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لوبیاپلوشیرازیToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.ToolStripMenuItem رنگمتنToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem رنگزمینهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پخشموزیکToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem w;
        private System.Windows.Forms.ToolStripMenuItem v;
        private System.Windows.Forms.ToolStripMenuItem aa;
        private System.Windows.Forms.ToolStripMenuItem bb;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem cc;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem1;
        private System.Windows.Forms.FontDialog fontDialog1;
    }
}

