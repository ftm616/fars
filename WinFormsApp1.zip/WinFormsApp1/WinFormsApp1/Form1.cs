﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class foorm : Form
    {
        public foorm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void شهرهایپرطرفداراستانفارسToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void شیرازToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox1.Visible = true;
            pictureBox1.Visible = true;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void مرودشتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = true;
            pictureBox2.Visible = true;
        }

        private void جهرمToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox3.Visible = true;
            pictureBox3.Visible = true;
        }

        private void آبادهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox4.Visible = true;
            pictureBox4.Visible = true;
        }

        private void لارToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;

            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox5.Visible = true;
            pictureBox5.Visible = true;
        }

        private void تختجمشیدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox6.Visible = true;
            pictureBox6.Visible = true;
            pictureBox7.Visible = true;
            pictureBox8.Visible = true;
            pictureBox9.Visible = true;
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void باغارمToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            textBox7.Visible = true;
            pictureBox10.Visible = true;
            pictureBox11.Visible = true;
            pictureBox12.Visible = true;
            pictureBox13.Visible = true;
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

        private void بازاروکیلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            textBox8.Visible = true;
            pictureBox14.Visible = true;
            pictureBox15.Visible = true;
            pictureBox16.Visible = true;
            pictureBox17.Visible = true;
        }

        private void آتوساToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox18.Visible = true;
            textBox9.Visible = true;
        }

        private void شاپورساسانیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox10.Visible = true;
            pictureBox19.Visible = true;
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void شیخروزبهانToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            textBox11.Visible = true;
            pictureBox20.Visible = true;
        }

        private void کلمپلوToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox12.Visible = true;
            pictureBox21.Visible = true;
        }

        private void شکرپلوToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox13.Visible = true;
            pictureBox22.Visible = true;
        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void قنبرپلوToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox15.Visible = false;
            pictureBox24.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox14.Visible = true;
            pictureBox23.Visible = true;
        }

        private void لوبیاپلوشیرازیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox7.Visible = false;
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            textBox14.Visible = false;
            pictureBox23.Visible = false;
            textBox13.Visible = false;
            pictureBox22.Visible = false;
            textBox12.Visible = false;
            pictureBox21.Visible = false;
            textBox8.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            pictureBox16.Visible = false;
            pictureBox17.Visible = false;
            textBox1.Visible = false;
            pictureBox1.Visible = false;
            textBox3.Visible = false;
            pictureBox3.Visible = false;
            textBox4.Visible = false;
            pictureBox4.Visible = false;
            textBox5.Visible = false;
            pictureBox5.Visible = false;
            textBox2.Visible = false;
            pictureBox2.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox18.Visible = false;
            textBox9.Visible = false;
            textBox10.Visible = false;
            pictureBox19.Visible = false;
            textBox11.Visible = false;
            pictureBox20.Visible = false;
            textBox15.Visible = true;
            pictureBox24.Visible = true;
        }

        private void رنگمتنToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void تنظیماتToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void سفیدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            if (aa.Checked)
             
              {  bb.Checked = false;
                cc.Checked = false;
                textBox1.ForeColor = Color.White;
                textBox2.ForeColor = Color.White;
                textBox3.ForeColor = Color.White;
                textBox4.ForeColor = Color.White;
                textBox5.ForeColor = Color.White;
                textBox6.ForeColor = Color.White;
                textBox7.ForeColor = Color.White;
                textBox8.ForeColor = Color.White;
                textBox9.ForeColor = Color.White;
                textBox10.ForeColor = Color.White;
                textBox11.ForeColor = Color.White;
                textBox12.ForeColor = Color.White;
                textBox13.ForeColor = Color.White;
                textBox14.ForeColor = Color.White;
                textBox15.ForeColor = Color.White;}

            
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void bb_Click(object sender, EventArgs e)
        {
           
            if (bb.Checked==true)
            {
                aa.Checked = false;
                cc.Checked = false;
                textBox1.ForeColor = Color.Black;
                textBox2.ForeColor = Color.Black;
                textBox3.ForeColor = Color.Black;
                textBox4.ForeColor = Color.Black;
                textBox5.ForeColor = Color.Black;
                textBox6.ForeColor = Color.Black;
                textBox7.ForeColor = Color.Black;
                textBox8.ForeColor = Color.Black;
                textBox9.ForeColor = Color.Black;
                textBox10.ForeColor = Color.Black;
                textBox11.ForeColor = Color.Black;
                textBox12.ForeColor = Color.Black;
                textBox13.ForeColor = Color.Black;
                textBox14.ForeColor = Color.Black;
                textBox15.ForeColor = Color.Black;
               
                
            }
        }

        private void رنگزمینهToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            colorDialog1.ShowDialog();
            this.BackColor = colorDialog1.Color;
            /*textBox1.BackColor = colorDialog1.Color;
            textBox2.BackColor = colorDialog1.Color;
            textBox3.BackColor = colorDialog1.Color;
            textBox4.BackColor = colorDialog1.Color;
            textBox5.BackColor = colorDialog1.Color;
            textBox6.BackColor = colorDialog1.Color;
            textBox7.BackColor = colorDialog1.Color;
            textBox8.BackColor = colorDialog1.Color;
            textBox9.BackColor = colorDialog1.Color;
            textBox10.BackColor = colorDialog1.Color;
            textBox11.BackColor = colorDialog1.Color;
            textBox12.BackColor = colorDialog1.Color;
            textBox13.BackColor = colorDialog1.Color;
            textBox14.BackColor = colorDialog1.Color;
            textBox15.BackColor = colorDialog1.Color;*/
        }

        private void pictureBox24_Click(object sender, EventArgs e)
        {

        }

        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }

        private void cc_Click(object sender, EventArgs e)
        {

            if (cc.Checked==true)
            {
                bb.Checked = false;
                aa.Checked = false;
                textBox1.ForeColor = Color.Blue;
                textBox2.ForeColor = Color.Blue;
                textBox3.ForeColor = Color.White;
                textBox4.ForeColor = Color.White;
                textBox5.ForeColor = Color.White;
                textBox6.ForeColor = Color.White;
                textBox7.ForeColor = Color.White;
                textBox8.ForeColor = Color.White;
                textBox9.ForeColor = Color.White;
                textBox10.ForeColor = Color.White;
                textBox11.ForeColor = Color.White;
                textBox12.ForeColor = Color.White;
                textBox13.ForeColor = Color.White;
                textBox14.ForeColor = Color.White;
                textBox15.ForeColor = Color.White;

            }
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void توقفموزیکToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer   player;
            player = new System.Media.SoundPlayer(@"sonds\mosic.WAV");
            player.Play();
            w.Checked = true;
            v.Checked = false;
        }

        private void پخشموزیکToolStripMenuItem_Click(object sender, EventArgs e)
        {

            fontDialog1.ShowDialog();
            textBox1.Font = fontDialog1.Font;
            textBox2.Font = fontDialog1.Font;
            textBox3.Font = fontDialog1.Font;
            textBox4.Font = fontDialog1.Font;
            textBox5.Font = fontDialog1.Font;
            textBox6.Font = fontDialog1.Font;
            textBox7.Font = fontDialog1.Font;
            textBox8.Font = fontDialog1.Font;
            textBox9.Font = fontDialog1.Font;
            textBox10.Font = fontDialog1.Font;
            textBox11.Font = fontDialog1.Font;
            textBox12.Font = fontDialog1.Font;
            textBox13.Font = fontDialog1.Font;
            textBox14.Font = fontDialog1.Font;
            textBox15.Font = fontDialog1.Font;
        }

        private void خروجToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }
    }
}